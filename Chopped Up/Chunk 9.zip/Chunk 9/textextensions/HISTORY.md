# History

## v2.2.0 2018 January 25
- Added a dozen or so new text extensions
    - Thanks to [jaswrks](https://github.com/jaswrks) for [pull request #5](https://github.com/bevry/textextensions/pull/5)

## v2.1.0 2017 April 24
- Added `noon` and `pug`
    - Thanks to [monsterkodi](https://github.com/monsterkodi) for [pull request #4](https://github.com/bevry/textextensions/pull/4)

## v2.0.1 2016 May 10
- JSON should have two space indentation

## v2.0.0 2016 May 10
- Now a json file

## v1.1.0 2016 May 10
- Added about 150 additional text extensions
    - Thanks to [FelipeBB](https://github.com/FelipeBB) for [pull request #3](https://github.com/bevry/textextensions/pull/3)

## v1.0.2 2016 May 2
- Updated meta files

## v1.0.1 2014 December 17
- Added `yml` extension
    - Thanks to [Jamy Timmermans](https://github.com/JamyDev) for [pull request #2](https://github.com/bevry/textextensions/pull/2)

## v1.0.0 2013 December 10
- Extracted from [bal-util](https://github.com/balupton/bal-util/blob/6501d51bc0244fce3781fc0150136f7493099237/src/lib/paths.coffee#L48-L79)
