# History

## v2.1.1 2018 January 26
- Fixed the `Unexpected end of input` error that you could experience under certain circumstances

## v2.1.0 2018 January 25
- Updated base files

## v2.0.0 2016 May 10
- Now a json file

## v1.0.1 2016 May 2
- Updated meta files

## v1.0.0 2013 December 10
- Extracted from [bal-util](https://github.com/balupton/bal-util/blob/6501d51bc0244fce3781fc0150136f7493099237/src/lib/paths.coffee#L81-L96)
