module.exports = require(process.env.COVER? './lib-cov' : './lib');
