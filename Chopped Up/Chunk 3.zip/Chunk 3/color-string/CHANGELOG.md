# 0.3.0

- Fixed: HSL alpha channel ([#16](https://github.com/harthur/color-string/pull/16))
- Fixed: ability to parse signed number ([#15](https://github.com/harthur/color-string/pull/15))
- Removed: component.json
- Removed: browser build
- Added: license field to package.json ([#17](https://github.com/harthur/color-string/pull/17))

---

Check out commit logs for earlier releases
