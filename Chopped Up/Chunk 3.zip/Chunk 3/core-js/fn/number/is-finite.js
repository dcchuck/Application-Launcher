require('../../modules/es6.number.is-finite');
module.exports = require('../../modules/_core').Number.isFinite;
