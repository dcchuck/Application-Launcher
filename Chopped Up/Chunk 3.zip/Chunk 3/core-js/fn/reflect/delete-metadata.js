require('../../modules/es7.reflect.delete-metadata');
module.exports = require('../../modules/_core').Reflect.deleteMetadata;
