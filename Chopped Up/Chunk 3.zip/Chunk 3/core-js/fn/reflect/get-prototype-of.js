require('../../modules/es6.reflect.get-prototype-of');
module.exports = require('../../modules/_core').Reflect.getPrototypeOf;
