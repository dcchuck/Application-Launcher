require('../../modules/es6.math.clz32');
module.exports = require('../../modules/_core').Math.clz32;
