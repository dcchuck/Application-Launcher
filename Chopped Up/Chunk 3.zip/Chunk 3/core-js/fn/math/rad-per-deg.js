require('../../modules/es7.math.rad-per-deg');
module.exports = 180 / Math.PI;
