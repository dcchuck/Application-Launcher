require('../../modules/es6.regexp.constructor');
module.exports = RegExp;
