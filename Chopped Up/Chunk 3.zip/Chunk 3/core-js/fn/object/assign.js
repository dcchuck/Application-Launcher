require('../../modules/es6.object.assign');
module.exports = require('../../modules/_core').Object.assign;
