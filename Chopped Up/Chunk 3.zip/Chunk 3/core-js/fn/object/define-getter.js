require('../../modules/es7.object.define-getter');
module.exports = require('../../modules/_core').Object.__defineGetter__;
