module.exports = Infinity;
