'use strict';

module.exports = function a (o) { return Object.prototype.toString.call(o) === '[object Array]'; };
