# Installation
> `npm install --save @types/openfin`

# Summary
This package contains type definitions for OpenFin API (https://openfin.co/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/openfin

Additional Details
 * Last updated: Thu, 29 Mar 2018 13:00:21 GMT
 * Dependencies: none
 * Global values: fin

# Credits
These definitions were written by Chris Barker <https://github.com/chrisbarker>, Ricardo de Pena <https://github.com/rdepena>.
