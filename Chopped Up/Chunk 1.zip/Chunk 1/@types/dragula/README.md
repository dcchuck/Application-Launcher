# Installation
> `npm install --save @types/dragula`

# Summary
This package contains type definitions for dragula (http://bevacqua.github.io/dragula/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/dragula

Additional Details
 * Last updated: Fri, 09 Mar 2018 00:01:00 GMT
 * Dependencies: none
 * Global values: dragula

# Credits
These definitions were written by Paul Welter <https://github.com/pwelter34>, Yang He <https://github.com/abruzzihraig>.
