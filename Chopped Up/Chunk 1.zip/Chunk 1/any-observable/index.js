'use strict';
module.exports = require('./register')().Observable;
