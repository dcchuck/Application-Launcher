'use strict';
require('../register')('rxjs', {Observable: require('rxjs').Observable});
