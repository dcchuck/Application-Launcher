// 2016 December 29
// https://github.com/bevry/editions
'use strict'

module.exports = require('editions').requirePackage(__dirname, require)
