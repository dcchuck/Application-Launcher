'use strict';

require('./typed.js');
require('./wrapped.js');
